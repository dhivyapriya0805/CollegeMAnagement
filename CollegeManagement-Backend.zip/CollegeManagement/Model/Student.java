package MyPack.CollegeManagement.Model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="students")
public class Student 
{
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	private Long Id;
	@Column(nullable=false)
    private String firstname;
	private String lastname;
	private String Gender;
	private String studentemail;
	private String password;
	private String course;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER,mappedBy="Student")

	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	
	public String getFirstname() 
	{
		return firstname;
	}
	
	public void setFirstname(String firstname) 
	{
		this.firstname = firstname;
	}
	public String getLastname() 
	{
		return lastname;
	}
	public void setLastname(String lastname) 
	{
		this.lastname = lastname;
	}
	public String getGender() 
	{
		return Gender;
	}
	public void setGender(String gender) 
	{
		Gender = gender;
	}
	public String getStudentemail() 
	{
		return studentemail;
	}
	public void setStudentemail(String studentemail) 
	{
		this.studentemail = studentemail;
	}
	public String getPassword() 
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	public String getCourse() 
	{
		return course;
	}
	public void setCourse(String course) 
	{
		this.course = course;
	}
	
	public Student(Long id, String firstname, String lastname, String gender, String studentemail, String password,
			String course) {
		super();
		Id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		Gender = gender;
		this.studentemail = studentemail;
		this.password = password;
		this.course = course;
	}
	public Student() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
		



}
