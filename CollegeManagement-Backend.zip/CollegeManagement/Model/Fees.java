package MyPack.CollegeManagement.Model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Fees")
public class Fees 
{
   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
   
   private Long Id;
   private String Studentname;
   private Long Studentno;
   private String Dept;
   private String Year;
   private Long Fee;
   private Long Paid;
   private Long Due;
   private String enddate;
    
   @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "Fees")
   
public Long getId() {
	return Id;
}
public void setId(Long id) {
	Id = id;
}
public String getStudentname() {
	return Studentname;
}
public void setStudentname(String studentname) {
	Studentname = studentname;
}

public Long getStudentno() {
	return Studentno;
}
public void setStudentno(Long studentno) {
	Studentno = studentno;
}
public String getDept() {
	return Dept;
}
public void setDept(String dept) {
	Dept = dept;
}
public String getYear() {
	return Year;
}
public void setYear(String year) {
	Year = year;
}
public Long getFee() {
	return Fee;
}
public void setFee(Long fee) {
	Fee = fee;
}
public Long getPaid() {
	return Paid;
}
public void setPaid(Long paid) {
	Paid = paid;
}
public Long getDue() {
	return Due;
}
public void setDue(Long due) {
	Due = due;
}
public String getEnddate() {
	return enddate;
}
public void setEnddate(String enddate) {
	this.enddate = enddate;
}


public Fees(Long id, String studentname, Long studentno, String dept, String year, Long fee, Long paid, Long due,
		String enddate) {
	super();
	Id = id;
	Studentname = studentname;
	Studentno = studentno;
	Dept = dept;
	Year = year;
	Fee = fee;
	Paid = paid;
	Due = due;
	this.enddate = enddate;
}
public Fees() {
	super();
	// TODO Auto-generated constructor stub
}
   
    
   
   
}
