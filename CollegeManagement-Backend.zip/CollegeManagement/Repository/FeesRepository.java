package MyPack.CollegeManagement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import MyPack.CollegeManagement.Model.Fees;

public interface FeesRepository extends JpaRepository<Fees, Long>
{
	

}
