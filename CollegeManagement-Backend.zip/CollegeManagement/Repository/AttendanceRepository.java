package MyPack.CollegeManagement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import MyPack.CollegeManagement.Model.Attendance;

public interface AttendanceRepository extends JpaRepository<Attendance, Long>
{
	

}
