package MyPack.CollegeManagement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import MyPack.CollegeManagement.Model.Faculty;

public interface FacultyRepository extends JpaRepository<Faculty, Long> {

}
