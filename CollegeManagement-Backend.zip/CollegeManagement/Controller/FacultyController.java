package MyPack.CollegeManagement.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import MyPack.CollegeManagement.Model.Faculty;
import MyPack.CollegeManagement.Service.FacultyServiceImpl;

@RestController
@RequestMapping("/faculty")
//we are using postman to do operations we need to add cross origin
@CrossOrigin("*")
public class FacultyController 
{
	@Autowired
	private FacultyServiceImpl facultyServiceImpl;
	
	@PostMapping("/saveFaculty")
	public Faculty saveFaculty(@RequestBody Faculty faculty)
	{
		System.out.println("faculty save works properly");
		facultyServiceImpl.saveFaculty(faculty);
		return faculty;
		
	}
	@GetMapping("/getfaculty")
	public List<Faculty> findaFaculties()
	{
		return facultyServiceImpl.findallFaculties();
	}
	
	@PutMapping("/updateFaculty")
	public Faculty updateFaculty(@RequestBody Faculty faculty)
	{
		return facultyServiceImpl.updateFaculty(faculty);
	}
	@DeleteMapping("/deletefaculty/{id}")
	public String deletefaculty(@PathVariable("id") long id)
	{
		facultyServiceImpl.deleteFaculty(id);
		return "faculty deleted";
	}
	


}
