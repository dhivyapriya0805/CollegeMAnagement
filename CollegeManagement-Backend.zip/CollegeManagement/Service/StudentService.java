package MyPack.CollegeManagement.Service;

import java.util.List;

import MyPack.CollegeManagement.Model.Student;

public interface StudentService {
	//to save new student
			public Student saveStudent(Student student);
			
			//to update student
			public Student updateStudent(Student student);
			
			//to fetch all student from database
			
			public List<Student> findallStudents();
			
			//to delete student
			public void deleteStudent(long StudentId);
			
}
