package MyPack.CollegeManagement.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import MyPack.CollegeManagement.Model.Course;
import MyPack.CollegeManagement.Repository.CourseRepository;

@Service
public class CourseServiceImpl  implements CourseService
{
private final CourseRepository courseRepository;
	
	@Autowired
    public CourseServiceImpl(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

	@Override
	public Course saveCourse(Course course) {
		// TODO Auto-generated method stub
		return courseRepository.save(course);
	}

	@Override
	public Course updateCourse(Course course) {
		// TODO Auto-generated method stub
		return courseRepository.save(course);
	}

	@Override
	public List<Course> findallCourses() {
		// TODO Auto-generated method stub
		return courseRepository.findAll();
	}

	@Override
	public void deleteCourse(long courseId) {
		// TODO Auto-generated method stub
		courseRepository.deleteById(courseId);
	}

}
