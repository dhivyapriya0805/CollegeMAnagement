package MyPack.CollegeManagement.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import MyPack.CollegeManagement.Model.Faculty;
import MyPack.CollegeManagement.Repository.FacultyRepository;

@Service
public class FacultyServiceImpl implements FacultyService
{
	@Autowired
    private FacultyRepository facultyRepository;
	@Override
	public Faculty saveFaculty(Faculty faculty) 
	{
		// TODO Auto-generated method stub
		return facultyRepository.save(faculty) ;
	}

	@Override
	public Faculty updateFaculty(Faculty faculty) 
	{
		// TODO Auto-generated method stub
		return facultyRepository.save(faculty);
	}

	@Override
	public List<Faculty> findallFaculties() 
	{
		//it returns a list so casting is needed
		// TODO Auto-generated method stub
		return facultyRepository.findAll();
	}

	@Override
	public void deleteFaculty(long FacultyId) 
	{
		// TODO Auto-generated method stub
		facultyRepository.deleteById(FacultyId);
		
	}

}
