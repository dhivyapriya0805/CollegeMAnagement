import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';

import { LoginComponent } from './pages/login/login.component';
import { FeesComponent } from './pages/admin/fees/fees.component';

import { AttendancesComponent } from './pages/Faculty/attendances/attendances.component';
import { AboutComponent } from './pages/about/about/about.component';
import { StudentSignupComponent } from './pages/Student/student-signup/student-signup.component';
import { FacultySignupComponent } from './pages/Admin/faculty-signup/faculty-signup.component';
import { CourseComponent } from './pages/Admin/Course/course/course.component';
import { AdminDashboardComponent } from './pages/admin/admin-dashboard/admin-dashboard.component';

import { SidebarComponent } from './pages/admin/sidebar/sidebar.component';
import { StudentLoginComponent } from './pages/Student/student-login/student-login.component';
import { ShowStudentComponent } from './pages/Student/show-student/show-student.component';
import { ShowFacultyComponent } from './pages/admin/show-faculty/show-faculty.component';
import { FacultyDashboardComponent } from './pages/Faculty/faculty-dashboard/faculty-dashboard.component';
import { StudentDashboardComponent } from './pages/Student/student-dashboard/student-dashboard.component';

const routes: Routes = [
  {
    path:'',
    component:HomeComponent,
    pathMatch:'full'
  },
  
  {
    path:'about',
    component:AboutComponent,
    pathMatch:'full'
  },
  {
    path:'fees',
    component:FeesComponent,
    pathMatch:'full'
  },
  {
    path:'login',
    component:LoginComponent,
    pathMatch:'full'
  },
  
  
  {
    path:'attendance',
    component:AttendancesComponent,
    pathMatch:'full'
  },
  {
    path:'student-signup',
    component:StudentSignupComponent,
    pathMatch:'full'
  },
  {
    path:'faculty-signup',
    component:FacultySignupComponent,
    pathMatch:'full'
  },
  
  {
    path:'course',
    component:CourseComponent,
    pathMatch:'full'
  },
  {
    path:'admin-dashboard',
    component:AdminDashboardComponent,
    pathMatch:'full'
  },
  {
    path:'sidebar',
    component:SidebarComponent,
    pathMatch:'full'
  },
  {
    path:'student-login',
    component:StudentLoginComponent,
    pathMatch:'full'
  },
  {
    path:'show-student',
    component:ShowStudentComponent,
    pathMatch:'full'
  },
  {
    path:'show-faculty',
    component:ShowFacultyComponent,
    pathMatch:'full'
  },
  {
    path:'faculty-dashboard',
    component:FacultyDashboardComponent,
    pathMatch:'full'
  },
  {
    path:'student-dashboard',
    component:StudentDashboardComponent,
    pathMatch:'full'
  }

  
  
  
  
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
