import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { LoginComponent } from './pages/login/login.component';

import { HomeComponent } from './pages/home/home.component';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material/input';
import {MatTableModule} from '@angular/material/table';
import {MatFormFieldModule} from '@angular/material/form-field';
import {  FormGroupName, FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import {MatCardModule} from '@angular/material/card';

import {MatButtonModule} from '@angular/material/button';
import {MatDialogModule} from '@angular/material/dialog';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatSelectModule} from '@angular/material/select';
import { FormGroup } from '@angular/forms';
import { AttendancesComponent } from './pages/Faculty/attendances/attendances.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FeesComponent } from './pages/admin/fees/fees.component';

import {MatDatepickerModule} from '@angular/material/datepicker';

import { AboutComponent } from './pages/about/about/about.component';
import { StudentSignupComponent } from './pages/Student/student-signup/student-signup.component';
import { FacultySignupComponent } from './pages/Admin/faculty-signup/faculty-signup.component';
import { CourseComponent } from './pages/Admin/Course/course/course.component';
import { AdminDashboardComponent } from './pages/admin/admin-dashboard/admin-dashboard.component';
import Swal from 'sweetalert2';
import { SidebarComponent } from './pages/admin/sidebar/sidebar.component';
import { StudentLoginComponent } from './pages/Student/student-login/student-login.component';
import { ShowStudentComponent } from './pages/Student/show-student/show-student.component';
import { ShowFacultyComponent } from './pages/admin/show-faculty/show-faculty.component';
import { FacultyDashboardComponent } from './pages/Faculty/faculty-dashboard/faculty-dashboard.component';
import { FacultySidebarComponent } from './pages/Faculty/faculty-sidebar/faculty-sidebar.component';
import { StudentDashboardComponent } from './pages/Student/student-dashboard/student-dashboard.component';
import { StudentSidebarComponent } from './pages/Student/student-sidebar/student-sidebar.component';







@NgModule({
  declarations: [
    AppComponent,
  
    NavbarComponent,
    LoginComponent,
    FeesComponent,
    HomeComponent,
    
    
    AttendancesComponent,
    FeesComponent,
    
    
    AboutComponent,
    StudentSignupComponent,
     FacultySignupComponent,
     CourseComponent,
     AdminDashboardComponent,
     SidebarComponent,
     StudentLoginComponent,
     ShowStudentComponent,
     ShowFacultyComponent,
     FacultyDashboardComponent,
     FacultySidebarComponent,
     StudentDashboardComponent,
     StudentSidebarComponent


     
     
    
   
    
    
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatToolbarModule,
    MatIconModule,
    MatTableModule,
    MatInputModule,
    MatFormFieldModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatDialogModule,
    MatSnackBarModule,
    MatSelectModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatDatepickerModule,

    
    
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
