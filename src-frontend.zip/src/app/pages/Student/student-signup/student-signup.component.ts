import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { StudentService } from 'src/app/Services/student.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-student-signup',
  templateUrl: './student-signup.component.html',
  styleUrls: ['./student-signup.component.css']
})
export class StudentSignupComponent implements  OnInit
 {
  ngOnInit(): void {}

  constructor(
    private studentService:StudentService,private snack:MatSnackBar,private router:Router
  ) {}
  
  public user={
    firstname:'',
    lastname:'',
    gender:'',
    studentemail:'',
    password:'',
    course:'',
    


  };
  formSubmit()
  {
    console.log(this.user)
    if(this.user.firstname=='' ||this.user.firstname==null)
    {
      //alert('user is required');
      this.snack.open('Username is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    if(this.user.lastname=='' ||this.user.lastname==null)
    {
      //alert('user is required');
      this.snack.open('lastname is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    if(this.user.gender=='' ||this.user.gender==null)
    {
      //alert('user is required');
      this.snack.open('Gender is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    if(this.user.studentemail=='' ||this.user.studentemail==null)
    {
      //alert('user is required');
      this.snack.open('Email is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    if(this.user.password=='' ||this.user.password==null)
    {
      //alert('user is required');
      this.snack.open('password is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    if(this.user.course=='' ||this.user.course==null)
    {
      //alert('user is required');
      this.snack.open('Course is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
   
    //validate

    // adduser:
    this.studentService.addStudent(this.user).subscribe(
    (data:any) => {
      //success
      console.log(data);
      //alert('success');
      // this.snack.open('Successfully Registered !!','',{
      //   duration:3000,
      // })
      Swal.fire(this.user.firstname+" "+this.user.lastname +' your registration successfully saved');
         },
    (error) =>
    {
      console.log(error);
      //alert('error');
      this.snack.open('something went wrong !!','',{
        duration:3000,
      })
    }
    );

   
    
  }

  onCancel(){
    //clear the components data
    this.user={
      firstname:'',
      lastname:'',
    gender:'',
    studentemail:'',
    password:'',
    course:'',
    

    
    }


  }
  
 


}
   
  



    
        
      
        
  
    
    
    

  
  