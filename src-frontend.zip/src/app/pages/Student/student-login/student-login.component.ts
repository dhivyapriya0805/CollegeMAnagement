import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from 'src/app/Services/student.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-student-login',
  templateUrl: './student-login.component.html',
  styleUrls: ['./student-login.component.css']
})
export class StudentLoginComponent implements OnInit{
  ngOnInit(): void {}
    
  constructor(private router:Router){

  }

  user_records:any[]=[];
  
  user={
    studentemail:'',
    password:''
  }

  doLogin(values:any){
    this.user_records=JSON.parse(localStorage.getItem("users")||'{}');
    if(this.user_records.some((v)=>{
      return v.studentemail==this.user.studentemail && v.password==this.user.password
    })){
      alert("Login Successful");
      this.router.navigate(['/student']);
    }
    else{
      alert("Login Failed");
    }
  }

}

