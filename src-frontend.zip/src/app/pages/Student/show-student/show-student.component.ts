import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/Services/student.service';

@Component({
  selector: 'app-show-student',
  templateUrl: './show-student.component.html',
  styleUrls: ['./show-student.component.css']
})
export class ShowStudentComponent implements OnInit {
  ngOnInit(): void {}
  studentAll:any;
  constructor(public studentService:StudentService) {
    this.getStudentDetails()
  }
  studentToUpdate={
    id:'',
    firstname:'',
    lastname:'',
    gender:'',
    studentemail:'',
    password:'',
    course:'',
    
  }

   getStudentDetails(){
    this.studentService.getStudent().subscribe(
      (data)=>{
        console.log(data);
        this.studentAll=data;
      
      },
    (error)=>{
      console.log(error);
    }
    )
  }

  edit(data:any){
    this.studentToUpdate=data;
  }

  updateStudent() {
    this.studentService.updateStudent(this.studentToUpdate).subscribe(
      (data)=>{
        console.log(data);

      },
      (error)=>{
        console.log(error);
      }
    )

  }

  deleteStudent(data:any) {
    this.studentService.deleteStudent(data.id).subscribe(
      (data)=>{
        console.log(data);
        this.getStudentDetails();
      },
      (error)=>{
        console.log(error);
      }
    )
  }


 
  

}
