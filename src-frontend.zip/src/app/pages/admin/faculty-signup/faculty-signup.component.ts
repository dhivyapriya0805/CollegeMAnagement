import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FacultyService } from 'src/app/Services/faculty.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-faculty-signup',
  templateUrl: './faculty-signup.component.html',
  styleUrls: ['./faculty-signup.component.css']
})
export class FacultySignupComponent implements OnInit
 {
  ngOnInit(): void {}
   
  constructor(
    private facultyservice:FacultyService,private snack:MatSnackBar
  ){}

  public faculty={
    fullName:'',
    gender:'',
    facultyEmail:'',
    password:'',
    designation:'',
    department:'',
    contact:'',
    address:'',

  };
 
  formSubmit()
  {
    console.log(this.faculty)
    if(this.faculty.fullName=='' ||this.faculty.fullName==null)
    {
      //alert('user is required');
      this.snack.open('Username is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    if(this.faculty.gender=='' ||this.faculty.gender==null)
    {
      //alert('user is required');
      this.snack.open('Gender is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    if(this.faculty.facultyEmail=='' ||this.faculty.facultyEmail==null)
    {
      //alert('user is required');
      this.snack.open('Email is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    if(this.faculty.designation=='' ||this.faculty.designation==null)
    {
      //alert('user is required');
      this.snack.open('Designation is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    if(this.faculty.password=='' ||this.faculty.password==null)
    {
      //alert('user is required');
      this.snack.open('Password is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    if(this.faculty.department=='' ||this.faculty.department==null)
    {
      //alert('user is required');
      this.snack.open('Department is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    if(this.faculty.contact=='' ||this.faculty.contact==null)
    {
      //alert('user is required');
      this.snack.open('Phone Number is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    if(this.faculty.address=='' ||this.faculty.address==null)
    {
      //alert('user is required');
      this.snack.open('Address is required !!', '',{
        duration:3000,
        verticalPosition:'top',
        horizontalPosition:'right',
      });
      return;
    }
    //validate

    //adduser:userservice
    this.facultyservice.addFaculty(this.faculty).subscribe(
    (data:any) => {
      //success
      console.log(data);
      //alert('success');
      // this.snack.open('Successfully Registered !!','',{
      //   duration:3000,
      // })
      Swal.fire(this.faculty.fullName +' your registration successfully saved');
         },
    (error) =>
    {
      console.log(error);
      //alert('error');
      this.snack.open('something went wrong !!','',{
        duration:3000,
      })
    }
    );
    
  }
  
  oncancel(){

    this.faculty={
      fullName:'',
    gender:'',
    facultyEmail:'',
    password:'',
    designation:'',
    department:'',
    contact:'',
    address:'',


    }
  }
  

}
