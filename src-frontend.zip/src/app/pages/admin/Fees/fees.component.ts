import { Component, OnInit } from '@angular/core';
import { FeesService } from 'src/app/Services/fees.service';
import {MatDatepickerModule} from '@angular/material/datepicker';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-fees',
  templateUrl: './fees.component.html',
  styleUrls: ['./fees.component.css']
})
export class FeesComponent implements OnInit{
  ngOnInit(): void {}

  feesAll:any;

  feesToUpdate={
    studentno:"",
    studentname:"",
    dept:"",
    year:"",
    fee:"",
    paid:"",
    due:"",
    enddate:""


  }

  constructor(public feesService:FeesService ) {
    this.getFeesDetails();
  }

  public fees={
    studentno: '',
    
    studentname:'',
    dept:'',
    year:'',
    fee:'',
    paid:'',
    due:'',
    enddate:''
  }

  formSubmit() {
      this.feesService.addFees(this.fees).subscribe(
        (data)=>{
          console.log(data);
          // alert('success');
          Swal.fire('Fees Added Successfully');
          this.getFeesDetails();
        },
        (error)=>{
          console.log(error);
          alert('wrong');
        }
      )
  }

  getFeesDetails(){
    this.feesService.getFees().subscribe(
      (data)=>{
        console.log(data);
        this.feesAll=data;
      
      },
    (error)=>{
      console.log(error);
    }
    )
  }

  edit(data:any){
    this.feesToUpdate=data;
  }

  updateFees() {
    this.feesService.updateFees(this.feesToUpdate).subscribe(
      (data)=>{
        console.log(data);
        Swal.fire('Updated Successfully');

      },
      (error)=>{
        console.log(error);
      }
    )

  }

  deleteFees(data:any) {
    this.feesService.deleteFees(data.id).subscribe(
      (data)=>{
        console.log(data);
        Swal.fire('Deleted Successfully');
        this.getFeesDetails();
      },
      (error)=>{
        console.log(error);
      }
    )
  }



}
