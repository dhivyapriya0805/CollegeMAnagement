import { Component, OnInit } from '@angular/core';
import { FacultyService } from 'src/app/Services/faculty.service';

@Component({
  selector: 'app-show-faculty',
  templateUrl: './show-faculty.component.html',
  styleUrls: ['./show-faculty.component.css']
})
export class ShowFacultyComponent implements OnInit {
  ngOnInit(): void {}
  constructor(public facultyService:FacultyService){
    this.getFacultyDetails()
  }
  facultyAll:any;
  facultyToUpdate={
    id:'',
    fullName:'',
    gender:'',
    facultyEmail:'',
    password:'',
    designation:'',
    department:'',
    contact:'',
    address:''
  }

   getFacultyDetails(){
    this.facultyService.getFaculty().subscribe(
      (data)=>{
        console.log(data);
        this.facultyAll=data;
      
      },
    (error)=>{
      console.log(error);
    }
    )
  }

  edit(data:any){
    this.facultyToUpdate=data;
  }

  updateFaculty() {
    this.facultyService.updateFaculty(this.facultyToUpdate).subscribe(
      (data)=>{
        console.log(data);

      },
      (error)=>{
        console.log(error);
      }
    )

  }

  deleteFaculty(data:any) {
    this.facultyService.deleteFaculty(data.id).subscribe(
      (data)=>{
        console.log(data);
        this.getFacultyDetails();
      },
      (error)=>{
        console.log(error);
      }
    )
  }
   

}
