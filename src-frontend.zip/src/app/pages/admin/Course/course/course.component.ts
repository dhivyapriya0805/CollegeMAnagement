import { Component, OnInit } from '@angular/core';
import { CourseService } from 'src/app/Services/course.service';
@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  ngOnInit(): void {}
  coursesAll: any;

  courseToUpdate = {
    courseId: '',
    courseName: '',
    courseCode: '',
    creditHours: ''
  };

  constructor(private courseService: CourseService) {
    this.getCourseDetails();
  }

  public course = {
    courseId: '',
    courseName: '',
    courseCode: '',
    creditHours: ''
  };

  formSubmit() {
    this.courseService.addCourse(this.course).subscribe(
      (data) => {
        console.log(data);
        alert('Course added successfully');
        this.getCourseDetails();
      },
      (error) => {
        console.log(error);
        alert('Error adding course');
      }
    );
  }

  getCourseDetails() {
    this.courseService.getCourse().subscribe(
      (res) => {
        console.log(res);
        this.coursesAll = res;
      },
      (err) => {
        console.log(err);
      }
    );
  }

  deleteCourse(data: any) {
    this.courseService.deleteCourse(data.courseId).subscribe(
      (res) => {
        console.log(res);
        this.getCourseDetails();
      },
      (err) => {
        console.log(err);
      }
    );
  }

  edit(data: any) {
    this.courseToUpdate = data;
  }

  updateCourse() {
    this.courseService.updateCourse(this.courseToUpdate).subscribe(
      (res) => {
        console.log(res);
      },
      (err) => {
        console.log(err);
      }
    );
  }
    
  

}
