import { Component } from '@angular/core';

@Component({
  selector: 'app-faculty-sidebar',
  templateUrl: './faculty-sidebar.component.html',
  styleUrls: ['./faculty-sidebar.component.css']
})
export class FacultySidebarComponent {

}
