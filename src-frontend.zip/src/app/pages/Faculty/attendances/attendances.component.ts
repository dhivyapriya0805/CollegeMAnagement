import { Component, OnInit } from '@angular/core';
import { OnSameUrlNavigation } from '@angular/router';
import { AttendanceService } from 'src/app/Services/attendance.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-attendances',
  templateUrl: './attendances.component.html',
  styleUrls: ['./attendances.component.css']
})
export class AttendancesComponent implements OnInit {
  ngOnInit(): void {}

  attendanceAll:any;

  attendanceToUpdate ={
      studentid:"",
      studname:"",
      dept:"",
      year:"",
      month:"",
      totaldays:"",
      noOfdayspresent:"",
      noOfdaysabsent:""
  }

  constructor(private attendanceService:AttendanceService) {
      this.getAttendanceDetails();
  }
   
  public attendance ={
    studentid:'',
    studname:'',
    dept:'',
    year:'',
    month:'',
    totaldays:'',
    noOfdayspresent:'',
    noOfdaysabsent:'',
    
  };

  formSubmit() {
    this.attendanceService.addAttendance(this.attendance).subscribe(
    (data)=>{
      console.log(data);
      // alert('success');
      Swal.fire('Attendance added successfully');
      this.getAttendanceDetails();
    },
    (error)=>{
      console.log(error);
      alert('wrong');
    }
    );
  }

  getAttendanceDetails(){
    this.attendanceService.getAttendance().subscribe(res=>{
      console.log(res);
      this.attendanceAll= res;
    },
    (err)=>{
      console.log(err);
    }

    )
  }

  deleteAttendance(data:any){
    this.attendanceService.deleteAttendance(data.id).subscribe(
      (res)=>{
        console.log(res);
        Swal.fire('Attendance deleted Successfully');
        this.getAttendanceDetails();
      },
      (err)=>{
        console.log(err);
      }
    )
  }
  
  edit(data:any){
    this.attendanceToUpdate=data;
  }

  updateAttendance(){
    this.attendanceService.updateAttendance(this.attendanceToUpdate).subscribe(
      (res)=>{
        console.log(res);
        Swal.fire('Attendance Updated Successfully');
      },
      (err)=>{
        console.log(err);
      }
    )
  }
  

}
