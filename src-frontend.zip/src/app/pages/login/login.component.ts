import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/Services/student.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{
  ngOnInit(): void {
    
  }
  constructor(
    private  router:Router
  ) {}

 
  public adminLogin={
    username:'',
    password:''
  }

  login()
  {
    console.log(this.adminLogin)
    if(this.adminLogin.username=='' ||this.adminLogin.username==null)
    {
      //alert('user is required');
      // this.snack.open('Username is required !!', '',{
      //   duration:3000,
      //   verticalPosition:'top',
      //   horizontalPosition:'right',
     
      Swal.fire('Username is Required');
      return;
    }
    if(this.adminLogin.password=='' ||this.adminLogin.password==null)
    {
      //alert('user is required');
      // this.snack.open('Password is required !!', '',{
      //   duration:3000,
      //   verticalPosition:'top',
      //   horizontalPosition:'right',
      // 
      Swal.fire('Password is Required');
      return;
    }
    if(this.adminLogin.username==='admin' &&this.adminLogin.password==='admin123')
    {
      
      Swal.fire('Admin Login Successfully !!!');
      this.router.navigate(['/admin-dashboard']);
      return;
    }
    else
      {
        Swal.fire('Username or Password is Not Valid');
      }

    }

    
    }
