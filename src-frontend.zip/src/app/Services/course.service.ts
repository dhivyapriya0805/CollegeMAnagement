import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class CourseService {

  constructor(private http:HttpClient) { }
  public addCourse(data: any) {
    return this.http.post('http://localhost:8080/course/saveCourse', data);
  }

  public getCourse() {
    return this.http.get('http://localhost:8080/course/getcourse');
  }

  public updateCourse(data: any) {
    return this.http.put('http://localhost:8080/course/updatecourse', data);
  }

  public deleteCourse(id: number) {
    return this.http.delete('http://localhost:8080/course/deletecourse/' + id);
  }
}
